This is my personal portfolio of projects for the ontroduction to Analytics course
